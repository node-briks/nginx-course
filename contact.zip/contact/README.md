# Contact API

A small Express + TypeScript backend with **no external database** — every
"table" is a JSON file under `data/` (see `src/storage/jsonFileStore.ts`).
Includes admin registration/login (JWT, cookie or Bearer), a public contact
form, a protected list endpoint, and full Swagger/OpenAPI docs.

## Folder structure

```
src/
  storage/     file-based JSON persistence (JsonFileStore, adminStorage, contactStorage)
  service/     business logic (authService, contactService)
  middleware/  authenticate, validateBody, errorHandler, notFound
  types/       shared TypeScript types & Express request augmentation
  helpers/     env, logger, jwt, password hashing, response envelope, zod schemas, swagger config
  handlers/    route controllers (authHandler, contactHandler)
  routes/      route definitions + Swagger JSDoc annotations
  app.ts       Express app wiring
  server.ts    entry point
data/
  admins.json    admin users (seeded as [])
  contacts.json  contact submissions (seeded as [])
```

## Setup

```bash
npm install
cp .env.example .env    # edit JWT_SECRET before using this for real
npm run dev              # ts-node-dev, auto-reloads
```

Build & run compiled JS:

```bash
npm run build
npm start
```

The server listens on `PORT` from `.env` (default `4000`).

## API

No `/api/v1`-style version prefix — routes are flat, top-level paths.

| Method | Path        | Auth                          | Body                                                              |
|--------|-------------|--------------------------------|--------------------------------------------------------------------|
| POST   | `/register` | none                            | `name`, `email`, `password`, `confirmPassword`                    |
| POST   | `/login`    | none                            | `email`, `password`                                                |
| POST   | `/contact`  | none (public)                    | `name`*, `email`*, `whatIsAbout`*, `company` (optional), `message`* (≤1000 chars) |
| GET    | `/contacts` | required (cookie or Bearer)      | —                                                                   |

`GET /health` and `GET /docs` (Swagger UI) are also available.

### Authentication

`POST /register` and `POST /login` both:
- set an `httpOnly` cookie (`token` by default, see `COOKIE_NAME`) with the JWT, and
- return the JWT in the JSON response body (`data.token`) for clients that
  prefer the `Authorization: Bearer <token>` header instead.

`GET /contacts` accepts **either**: the cookie set at login, or an
`Authorization: Bearer <token>` header. Requests with neither, or with an
invalid/expired token, get `401 Unauthorized`.

### Example requests

```bash
# Register the first admin
curl -X POST http://localhost:4000/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Doe","email":"jane@example.com","password":"SuperSecret123","confirmPassword":"SuperSecret123"}'

# Submit a contact message (public)
curl -X POST http://localhost:4000/contact \
  -H "Content-Type: application/json" \
  -d '{"name":"John Smith","email":"john@example.com","whatIsAbout":"Partnership","company":"Acme","message":"Hello there"}'

# List contacts using a Bearer token
curl http://localhost:4000/contacts -H "Authorization: Bearer <token>"
```

## Swagger

Interactive docs: `http://localhost:4000/docs`
Raw OpenAPI JSON: `http://localhost:4000/docs.json`

## Notes

- Passwords are hashed with bcrypt (`bcryptjs`), never stored or returned in plain text.
- Request bodies are validated with `zod`; failures return `422` with a field-level error list.
- All responses share one envelope: `{ success, message, data? }` or `{ success, message, errors? }`.
- Data files (`data/*.json`) are written through a per-file write queue so concurrent
  requests can't corrupt them — good enough for a course/demo app, not a
  substitute for a real database under real concurrent load.
