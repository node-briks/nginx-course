import { AdminUser } from "../types/admin.types";
import { JsonFileStore } from "./jsonFileStore";

const store = new JsonFileStore<AdminUser>("admins.json");

export const adminStorage = {
  async findByEmail(email: string): Promise<AdminUser | undefined> {
    return store.find((admin) => admin.email === email.toLowerCase());
  },

  async create(admin: AdminUser): Promise<AdminUser> {
    return store.insert(admin);
  },

  async findAll(): Promise<AdminUser[]> {
    return store.findAll();
  },
};
