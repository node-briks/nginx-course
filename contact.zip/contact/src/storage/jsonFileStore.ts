import { promises as fs } from "fs";
import path from "path";
import { logger } from "../helpers/logger";

/**
 * A minimal JSON-file-backed collection store. This project intentionally
 * avoids running a real database engine (SQL/NoSQL server) - every
 * "table" is just an array of records serialized to a JSON file on disk.
 *
 * Writes are serialized through an in-memory promise chain per instance so
 * concurrent requests can't interleave reads/writes and corrupt the file.
 */
export class JsonFileStore<T> {
  private readonly filePath: string;
  private writeQueue: Promise<unknown> = Promise.resolve();

  constructor(fileName: string) {
    this.filePath = path.join(process.cwd(), "data", fileName);
  }

  private async ensureFile(): Promise<void> {
    try {
      await fs.access(this.filePath);
    } catch {
      await fs.mkdir(path.dirname(this.filePath), { recursive: true });
      await fs.writeFile(this.filePath, "[]", "utf-8");
      logger.info(`Created new data file at ${this.filePath}`);
    }
  }

  private async readAll(): Promise<T[]> {
    await this.ensureFile();
    const raw = await fs.readFile(this.filePath, "utf-8");
    if (!raw.trim()) {
      return [];
    }
    try {
      return JSON.parse(raw) as T[];
    } catch (error) {
      logger.error(`Failed to parse ${this.filePath}, resetting to empty array`, error);
      return [];
    }
  }

  private async writeAll(records: T[]): Promise<void> {
    await fs.writeFile(this.filePath, JSON.stringify(records, null, 2), "utf-8");
  }

  /** Queues an operation so it never overlaps another read/write on this file. */
  private enqueue<R>(operation: () => Promise<R>): Promise<R> {
    const result = this.writeQueue.then(operation, operation);
    // Swallow errors here so one failed op doesn't stall the queue; the
    // caller still receives the rejection via `result`.
    this.writeQueue = result.catch(() => undefined);
    return result;
  }

  async findAll(): Promise<T[]> {
    return this.enqueue(() => this.readAll());
  }

  async find(predicate: (item: T) => boolean): Promise<T | undefined> {
    const all = await this.enqueue(() => this.readAll());
    return all.find(predicate);
  }

  async insert(record: T): Promise<T> {
    return this.enqueue(async () => {
      const all = await this.readAll();
      all.push(record);
      await this.writeAll(all);
      return record;
    });
  }
}
