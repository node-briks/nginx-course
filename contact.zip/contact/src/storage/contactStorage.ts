import { Contact } from "../types/contact.types";
import { JsonFileStore } from "./jsonFileStore";

const store = new JsonFileStore<Contact>("contacts.json");

export const contactStorage = {
  async create(contact: Contact): Promise<Contact> {
    return store.insert(contact);
  },

  async findAll(): Promise<Contact[]> {
    const all = await store.findAll();
    // Newest first is the most useful default for a list view.
    return [...all].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  },
};
