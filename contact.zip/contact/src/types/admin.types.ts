/**
 * The admin user record as persisted in local storage.
 * The password is never stored or returned in plain text.
 */
export interface AdminUser {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  createdAt: string;
  updatedAt: string;
}

/** Admin fields that are safe to expose in API responses. */
export type PublicAdminUser = Omit<AdminUser, "passwordHash">;

export interface RegisterAdminInput {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthResult {
  admin: PublicAdminUser;
  token: string;
}
