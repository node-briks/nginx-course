import { JwtPayload } from "./auth.types";

// Augment Express's Request type so authenticated handlers can read
// `req.user` without casting.
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

export {};
