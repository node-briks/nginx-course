/** A contact-us submission as persisted in local storage. */
export interface Contact {
  id: string;
  name: string;
  email: string;
  whatIsAbout: string;
  company?: string;
  message: string;
  createdAt: string;
}

export interface CreateContactInput {
  name: string;
  email: string;
  whatIsAbout: string;
  company?: string;
  message: string;
}
