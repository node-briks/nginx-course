/** Payload embedded inside signed JWTs. */
export interface JwtPayload {
  sub: string;
  email: string;
}
