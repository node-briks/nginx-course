import { NextFunction, Request, Response } from "express";
import { AppError } from "../helpers/AppError";
import { sendError } from "../helpers/response";
import { logger } from "../helpers/logger";
import { env } from "../helpers/env";

/**
 * Central error handler. Must be registered last, after all routes.
 * Known `AppError`s are reported with their intended status code and
 * message; anything unexpected is logged and reported as a generic 500
 * so internals are never leaked to the client.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  if (err instanceof AppError) {
    sendError(res, err.statusCode, err.message, err.errors);
    return;
  }

  logger.error("Unhandled error", err);
  sendError(
    res,
    500,
    env.isProduction ? "Internal server error" : (err as Error)?.message || "Internal server error"
  );
}
