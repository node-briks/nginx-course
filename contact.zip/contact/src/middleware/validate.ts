import { NextFunction, Request, Response } from "express";
import { ZodError, ZodTypeAny } from "zod";
import { sendError } from "../helpers/response";

/**
 * Builds a middleware that validates `req.body` against a Zod schema.
 * On success, `req.body` is replaced with the parsed (and coerced/trimmed)
 * value. On failure, responds 422 with a field-level error list.
 *
 * Accepts any Zod schema (including `.refine()`-wrapped `ZodEffects`, used
 * for the register schema's password/confirmPassword check), not just a
 * plain `ZodObject`.
 */
export function validateBody(schema: ZodTypeAny) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const result = schema.safeParse(req.body);

    if (!result.success) {
      const errors = (result.error as ZodError).errors.map((issue) => ({
        field: issue.path.join(".") || undefined,
        message: issue.message,
      }));
      sendError(res, 422, "Validation failed", errors);
      return;
    }

    req.body = result.data;
    next();
  };
}
