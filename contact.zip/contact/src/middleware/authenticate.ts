import { NextFunction, Request, Response } from "express";
import { verifyToken } from "../helpers/jwt";
import { AppError } from "../helpers/AppError";
import { env } from "../helpers/env";

/**
 * Requires a valid session. Accepts the token from either:
 *  - an httpOnly cookie (set on login), or
 *  - an `Authorization: Bearer <token>` header.
 * On success, attaches the decoded payload to `req.user`.
 */
export function authenticate(req: Request, _res: Response, next: NextFunction): void {
  const cookieToken = req.cookies?.[env.cookieName] as string | undefined;

  const authHeader = req.headers.authorization;
  const bearerToken =
    authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : undefined;

  const token = cookieToken || bearerToken;

  if (!token) {
    return next(new AppError("Authentication required", 401));
  }

  try {
    req.user = verifyToken(token);
    next();
  } catch {
    next(new AppError("Invalid or expired token", 401));
  }
}
