import { Router } from "express";
import { contactHandler } from "../handlers/contactHandler";
import { authenticate } from "../middleware/authenticate";
import { validateBody } from "../middleware/validate";
import { createContactSchema } from "../helpers/validation/contactValidation";

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     CreateContactRequest:
 *       type: object
 *       required: [name, email, whatIsAbout, message]
 *       properties:
 *         name:
 *           type: string
 *           example: John Smith
 *         email:
 *           type: string
 *           format: email
 *           example: john@example.com
 *         whatIsAbout:
 *           type: string
 *           example: Partnership inquiry
 *         company:
 *           type: string
 *           example: Acme Inc.
 *         message:
 *           type: string
 *           maxLength: 1000
 *           example: We'd love to discuss a potential partnership.
 *     Contact:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         name:
 *           type: string
 *         email:
 *           type: string
 *         whatIsAbout:
 *           type: string
 *         company:
 *           type: string
 *         message:
 *           type: string
 *         createdAt:
 *           type: string
 */

/**
 * @swagger
 * /contact:
 *   post:
 *     summary: Submit a contact-us message (public, no authentication required)
 *     tags: [Contact]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateContactRequest'
 *     responses:
 *       201:
 *         description: Contact submitted successfully
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiSuccessResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/Contact'
 *       422:
 *         description: Validation failed
 */
router.post("/contact", validateBody(createContactSchema), contactHandler.createContact);

/**
 * @swagger
 * /contacts:
 *   get:
 *     summary: List all contact-us submissions (requires authentication)
 *     tags: [Contact]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Contacts retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiSuccessResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Contact'
 *       401:
 *         description: Authentication required or invalid/expired token
 */
router.get("/contacts", authenticate, contactHandler.listContacts);

export default router;
