import { Router } from "express";
import authRoutes from "./authRoutes";
import contactRoutes from "./contactRoutes";

const router = Router();

// Flat, top-level paths on purpose: /register, /login, /contact, /contacts.
// No "/api/v1" style prefix is applied anywhere in this app.
router.use(authRoutes);
router.use(contactRoutes);

export default router;
