import { Router } from "express";
import { authHandler } from "../handlers/authHandler";
import { validateBody } from "../middleware/validate";
import { registerAdminSchema, loginSchema } from "../helpers/validation/authValidation";

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     RegisterAdminRequest:
 *       type: object
 *       required: [name, email, password, confirmPassword]
 *       properties:
 *         name:
 *           type: string
 *           example: Jane Doe
 *         email:
 *           type: string
 *           format: email
 *           example: jane@example.com
 *         password:
 *           type: string
 *           format: password
 *           minLength: 8
 *           example: SuperSecret123
 *         confirmPassword:
 *           type: string
 *           format: password
 *           example: SuperSecret123
 *     LoginRequest:
 *       type: object
 *       required: [email, password]
 *       properties:
 *         email:
 *           type: string
 *           format: email
 *           example: jane@example.com
 *         password:
 *           type: string
 *           format: password
 *           example: SuperSecret123
 *     PublicAdmin:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         name:
 *           type: string
 *         email:
 *           type: string
 *         createdAt:
 *           type: string
 *         updatedAt:
 *           type: string
 *     AuthResult:
 *       type: object
 *       properties:
 *         admin:
 *           $ref: '#/components/schemas/PublicAdmin'
 *         token:
 *           type: string
 */

/**
 * @swagger
 * /register:
 *   post:
 *     summary: Register a new admin user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterAdminRequest'
 *     responses:
 *       201:
 *         description: Admin registered successfully. Also sets an httpOnly auth cookie.
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiSuccessResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AuthResult'
 *       409:
 *         description: An admin with this email already exists
 *       422:
 *         description: Validation failed
 */
router.post("/register", validateBody(registerAdminSchema), authHandler.register);

/**
 * @swagger
 * /login:
 *   post:
 *     summary: Log in as an admin user
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *     responses:
 *       200:
 *         description: Login successful. Also sets an httpOnly auth cookie.
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiSuccessResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AuthResult'
 *       401:
 *         description: Invalid email or password
 *       422:
 *         description: Validation failed
 */
router.post("/login", validateBody(loginSchema), authHandler.login);

export default router;
