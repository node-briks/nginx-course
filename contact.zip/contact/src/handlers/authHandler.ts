import { Request, Response } from "express";
import { authService } from "../service/authService";
import { asyncHandler } from "../helpers/asyncHandler";
import { sendSuccess } from "../helpers/response";
import { env } from "../helpers/env";
import { RegisterAdminInput, LoginInput } from "../types/admin.types";

const COOKIE_MAX_AGE_MS = 24 * 60 * 60 * 1000; // 1 day

function setAuthCookie(res: Response, token: string): void {
  res.cookie(env.cookieName, token, {
    httpOnly: true,
    secure: env.isProduction,
    sameSite: "lax",
    maxAge: COOKIE_MAX_AGE_MS,
  });
}

export const authHandler = {
  register: asyncHandler(async (req: Request, res: Response) => {
    const input = req.body as RegisterAdminInput;
    const result = await authService.registerAdmin(input);
    setAuthCookie(res, result.token);
    sendSuccess(res, 201, "Admin registered successfully", result);
  }),

  login: asyncHandler(async (req: Request, res: Response) => {
    const input = req.body as LoginInput;
    const result = await authService.login(input);
    setAuthCookie(res, result.token);
    sendSuccess(res, 200, "Login successful", result);
  }),
};
