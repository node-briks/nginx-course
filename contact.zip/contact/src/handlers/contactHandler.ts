import { Request, Response } from "express";
import { contactService } from "../service/contactService";
import { asyncHandler } from "../helpers/asyncHandler";
import { sendSuccess } from "../helpers/response";
import { CreateContactInput } from "../types/contact.types";

export const contactHandler = {
  createContact: asyncHandler(async (req: Request, res: Response) => {
    const input = req.body as CreateContactInput;
    const contact = await contactService.createContact(input);
    sendSuccess(res, 201, "Contact submitted successfully", contact);
  }),

  listContacts: asyncHandler(async (_req: Request, res: Response) => {
    const contacts = await contactService.listContacts();
    sendSuccess(res, 200, "Contacts retrieved successfully", contacts);
  }),
};
