import { adminStorage } from "../storage/adminStorage";
import { AppError } from "../helpers/AppError";
import { comparePassword, hashPassword } from "../helpers/password";
import { signToken } from "../helpers/jwt";
import { generateId } from "../helpers/id";
import {
  AdminUser,
  AuthResult,
  LoginInput,
  PublicAdminUser,
  RegisterAdminInput,
} from "../types/admin.types";

function toPublicAdmin(admin: AdminUser): PublicAdminUser {
  const { passwordHash, ...publicAdmin } = admin;
  void passwordHash;
  return publicAdmin;
}

export const authService = {
  async registerAdmin(input: RegisterAdminInput): Promise<AuthResult> {
    const email = input.email.toLowerCase();

    const existing = await adminStorage.findByEmail(email);
    if (existing) {
      throw new AppError("An admin with this email already exists", 409);
    }

    const now = new Date().toISOString();
    const admin: AdminUser = {
      id: generateId(),
      name: input.name,
      email,
      passwordHash: await hashPassword(input.password),
      createdAt: now,
      updatedAt: now,
    };

    await adminStorage.create(admin);

    const token = signToken({ sub: admin.id, email: admin.email });
    return { admin: toPublicAdmin(admin), token };
  },

  async login(input: LoginInput): Promise<AuthResult> {
    const email = input.email.toLowerCase();
    const admin = await adminStorage.findByEmail(email);

    if (!admin) {
      throw new AppError("Invalid email or password", 401);
    }

    const isPasswordValid = await comparePassword(input.password, admin.passwordHash);
    if (!isPasswordValid) {
      throw new AppError("Invalid email or password", 401);
    }

    const token = signToken({ sub: admin.id, email: admin.email });
    return { admin: toPublicAdmin(admin), token };
  },
};
