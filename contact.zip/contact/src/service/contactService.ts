import { contactStorage } from "../storage/contactStorage";
import { generateId } from "../helpers/id";
import { Contact, CreateContactInput } from "../types/contact.types";

export const contactService = {
  async createContact(input: CreateContactInput): Promise<Contact> {
    const contact: Contact = {
      id: generateId(),
      name: input.name,
      email: input.email.toLowerCase(),
      whatIsAbout: input.whatIsAbout,
      company: input.company,
      message: input.message,
      createdAt: new Date().toISOString(),
    };

    return contactStorage.create(contact);
  },

  async listContacts(): Promise<Contact[]> {
    return contactStorage.findAll();
  },
};
