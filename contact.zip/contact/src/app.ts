import express, { Application } from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import cookieParser from "cookie-parser";
import swaggerUi from "swagger-ui-express";
import routes from "./routes";
import { notFound } from "./middleware/notFound";
import { errorHandler } from "./middleware/errorHandler";
import { swaggerSpec } from "./helpers/swagger";
import { env } from "./helpers/env";
import { sendSuccess } from "./helpers/response";

export function createApp(): Application {
  const app = express();

  app.disable("x-powered-by");
  app.use(helmet());
  app.use(
    cors({
      origin: env.corsOrigin === "*" ? true : env.corsOrigin.split(","),
      credentials: true,
    })
  );
  app.use(express.json({ limit: "50kb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use(cookieParser());
  app.use(morgan(env.isProduction ? "combined" : "dev"));

  app.get("/health", (_req, res) => {
    sendSuccess(res, 200, "Service is healthy", { uptime: process.uptime() });
  });

  app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  app.get("/docs.json", (_req, res) => {
    res.json(swaggerSpec);
  });

  // No "/api/v1" style version prefix - routes are mounted at the app root.
  app.use(routes);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}
