import { Response } from "express";
import { ApiErrorResponse, ApiSuccessResponse } from "../types/api.types";

export function sendSuccess<T>(
  res: Response,
  statusCode: number,
  message: string,
  data?: T
): void {
  const body: ApiSuccessResponse<T> = { success: true, message, data };
  res.status(statusCode).json(body);
}

export function sendError(
  res: Response,
  statusCode: number,
  message: string,
  errors?: Array<{ field?: string; message: string }>
): void {
  const body: ApiErrorResponse = { success: false, message, errors };
  res.status(statusCode).json(body);
}
