import { z } from "zod";

export const createContactSchema = z.object({
  name: z
    .string({ required_error: "name is required" })
    .trim()
    .min(1, "name is required")
    .max(100, "name must be at most 100 characters"),
  email: z
    .string({ required_error: "email is required" })
    .trim()
    .toLowerCase()
    .email("email must be a valid email address"),
  whatIsAbout: z
    .string({ required_error: "whatIsAbout is required" })
    .trim()
    .min(1, "whatIsAbout is required")
    .max(200, "whatIsAbout must be at most 200 characters"),
  company: z
    .string()
    .trim()
    .max(150, "company must be at most 150 characters")
    .optional(),
  message: z
    .string({ required_error: "message is required" })
    .trim()
    .min(1, "message is required")
    .max(1000, "message must be at most 1000 characters"),
});

export type CreateContactSchema = z.infer<typeof createContactSchema>;
