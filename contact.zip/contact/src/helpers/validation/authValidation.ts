import { z } from "zod";

export const registerAdminSchema = z
  .object({
    name: z
      .string({ required_error: "name is required" })
      .trim()
      .min(2, "name must be at least 2 characters")
      .max(100, "name must be at most 100 characters"),
    email: z
      .string({ required_error: "email is required" })
      .trim()
      .toLowerCase()
      .email("email must be a valid email address"),
    password: z
      .string({ required_error: "password is required" })
      .min(8, "password must be at least 8 characters")
      .max(128, "password must be at most 128 characters"),
    confirmPassword: z.string({
      required_error: "confirmPassword is required",
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "password and confirmPassword must match",
    path: ["confirmPassword"],
  });

export const loginSchema = z.object({
  email: z
    .string({ required_error: "email is required" })
    .trim()
    .toLowerCase()
    .email("email must be a valid email address"),
  password: z.string({ required_error: "password is required" }).min(1, "password is required"),
});

export type RegisterAdminSchema = z.infer<typeof registerAdminSchema>;
export type LoginSchema = z.infer<typeof loginSchema>;
