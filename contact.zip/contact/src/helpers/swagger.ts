import swaggerJsdoc from "swagger-jsdoc";
import path from "path";
import { env } from "./env";

const options: swaggerJsdoc.Options = {
  definition: {
    openapi: "3.0.3",
    info: {
      title: "Contact API",
      version: "1.0.0",
      description:
        "Admin auth (register/login) and a public contact form with a protected list endpoint. " +
        "Local, file-based storage - no external database required.",
    },
    servers: [{ url: `http://localhost:${env.port}`, description: "Local server" }],
    components: {
      schemas: {
        ApiSuccessResponse: {
          type: "object",
          properties: {
            success: { type: "boolean", example: true },
            message: { type: "string" },
            data: { type: "object" },
          },
        },
        ApiErrorResponse: {
          type: "object",
          properties: {
            success: { type: "boolean", example: false },
            message: { type: "string" },
            errors: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  field: { type: "string" },
                  message: { type: "string" },
                },
              },
            },
          },
        },
      },
      securitySchemes: {
        cookieAuth: {
          type: "apiKey",
          in: "cookie",
          name: env.cookieName,
        },
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
  },
  // Absolute glob so it resolves the same whether ts-node runs src/*.ts
  // or the compiled app runs dist/*.js.
  apis: [path.join(__dirname, "..", "routes", "*.{ts,js}")],
};

export const swaggerSpec = swaggerJsdoc(options);
