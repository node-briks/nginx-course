/**
 * Operational error carrying an HTTP status code. Throw this from services
 * and handlers for any expected failure (validation, auth, not found, etc.)
 * so the central error middleware can turn it into a clean JSON response.
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly errors?: Array<{ field?: string; message: string }>;

  constructor(
    message: string,
    statusCode = 500,
    errors?: Array<{ field?: string; message: string }>
  ) {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
    this.isOperational = true;
    this.errors = errors;
    Object.setPrototypeOf(this, AppError.prototype);
  }
}
