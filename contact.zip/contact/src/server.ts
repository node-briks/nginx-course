import { createApp } from "./app";
import { env } from "./helpers/env";
import { logger } from "./helpers/logger";

const app = createApp();

app.listen(env.port, () => {
  logger.info(`Contact API listening on http://localhost:${env.port}`);
  logger.info(`Swagger docs available at http://localhost:${env.port}/docs`);
});
