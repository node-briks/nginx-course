(function () {
  'use strict';

  var yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();

  var courses  = Array.prototype.slice.call(document.querySelectorAll('.course'));
  var cats     = Array.prototype.slice.call(document.querySelectorAll('.cat'));
  var chips    = Array.prototype.slice.call(document.querySelectorAll('.chip'));
  var input    = document.getElementById('q');
  var countEl  = document.getElementById('count');
  var emptyEl  = document.getElementById('empty');
  var expandEl = document.getElementById('expand');

  var filter = 'all';
  var query = '';

  function apply() {
    var shown = 0;

    courses.forEach(function (card) {
      var inCat = filter === 'all' || card.getAttribute('data-cat') === filter;
      var hit = !query || card.getAttribute('data-search').indexOf(query) !== -1;
      var visible = inCat && hit;
      card.hidden = !visible;
      if (visible) shown++;
    });

    cats.forEach(function (cat) {
      var any = cat.querySelector('.course:not([hidden])');
      cat.hidden = !any;
    });

    countEl.textContent = shown === 1 ? '1 course' : shown + ' courses';
    emptyEl.hidden = shown !== 0;
  }

  if (input) {
    input.addEventListener('input', function () {
      query = input.value.trim().toLowerCase();
      apply();
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { input.value = ''; query = ''; apply(); }
    });
  }

  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('is-on'); });
      chip.classList.add('is-on');
      filter = chip.getAttribute('data-filter');
      apply();
    });
  });

  if (expandEl) {
    expandEl.addEventListener('click', function () {
      var open = expandEl.getAttribute('data-state') === 'open';
      Array.prototype.forEach.call(
        document.querySelectorAll('.course:not([hidden]) .toc'),
        function (d) { d.open = !open; }
      );
      expandEl.setAttribute('data-state', open ? 'closed' : 'open');
      expandEl.textContent = open ? 'Expand all' : 'Collapse all';
    });
  }

  /* Playlist links are placeholders until each course is recorded. */
  Array.prototype.forEach.call(document.querySelectorAll('.playlist'), function (a) {
    a.addEventListener('click', function (e) {
      if (a.getAttribute('href') === '#') {
        e.preventDefault();
        var was = a.textContent;
        a.textContent = 'Not recorded yet';
        setTimeout(function () { a.textContent = was; }, 1600);
      }
    });
  });
})();
