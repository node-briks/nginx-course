(function () {
  'use strict';

  document.documentElement.classList.add('js');

  var yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------------------
     Parallax: floating tech logos in the hero plus the portrait.
     Scroll moves each layer at its own rate; pointer position
     nudges them sideways. One rAF loop drives everything.
     --------------------------------------------------------- */
  var hero = document.querySelector('.hero');
  var layers = [];

  if (hero && !reduce) {
    Array.prototype.forEach.call(hero.querySelectorAll('.tech'), function (el) {
      layers.push({ el: el, depth: parseFloat(el.getAttribute('data-depth')) || 1, sway: 34 });
    });
    Array.prototype.forEach.call(document.querySelectorAll('[data-parallax]'), function (el) {
      layers.push({ el: el, depth: parseFloat(el.getAttribute('data-parallax')) || 0.4, sway: 8 });
    });
  }

  if (layers.length) {
    var px = 0, py = 0;      // pointer, -1 to 1
    var tx = 0, ty = 0;      // eased pointer
    var scrolled = 0;
    var running = false;

    window.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') return;
      var r = hero.getBoundingClientRect();
      px = ((e.clientX - r.left) / r.width - 0.5) * 2;
      py = ((e.clientY - r.top) / r.height - 0.5) * 2;
      start();
    }, { passive: true });

    window.addEventListener('scroll', function () {
      scrolled = window.pageYOffset || document.documentElement.scrollTop;
      start();
    }, { passive: true });

    function start() {
      if (running) return;
      running = true;
      requestAnimationFrame(frame);
    }

    function frame() {
      tx += (px - tx) * 0.08;
      ty += (py - ty) * 0.08;

      for (var i = 0; i < layers.length; i++) {
        var l = layers[i];
        var x = tx * l.sway * l.depth;
        var y = ty * (l.sway * 0.6) * l.depth - scrolled * 0.16 * l.depth;
        l.el.style.transform = 'translate3d(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px,0)';
      }

      var settled = Math.abs(px - tx) < 0.001 && Math.abs(py - ty) < 0.001;
      if (settled) { running = false; } else { requestAnimationFrame(frame); }
    }

    frame();
  }

  /* ---------------------------------------------------------
     Reveal sections on scroll. Anything already on screen at
     load stays visible, so the first frame is never blank.
     --------------------------------------------------------- */
  if (reduce || !('IntersectionObserver' in window)) return;

  var vh = window.innerHeight || 800;

  Array.prototype.forEach.call(document.querySelectorAll('.block, .rail'), function (el) {
    if (el.getBoundingClientRect().top < vh * 0.9) return;
    el.classList.add('reveal');
  });

  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });

  Array.prototype.forEach.call(document.querySelectorAll('.reveal'), function (el) {
    io.observe(el);
  });

  setTimeout(function () {
    Array.prototype.forEach.call(document.querySelectorAll('.reveal:not(.in)'), function (el) {
      el.classList.add('in');
    });
  }, 2500);
})();


/* Contact modal: "Contact Me" opens a form in a dialog. Without JS the
   button stays a plain mailto link. */
(function () {
  'use strict';
  var dlg = document.getElementById('contact-modal');
  var form = document.getElementById('cm-form');
  var note = document.getElementById('cm-note');
  if (!dlg || !form || typeof dlg.showModal !== 'function') return;

  var PLACEHOLDER = 'REPLACE-WITH-YOUR-WEB3FORMS-KEY';
  var lastTrigger = null;

  function open(e) {
    if (e) e.preventDefault();
    lastTrigger = e ? e.currentTarget : null;
    note.textContent = '';
    dlg.showModal();
    document.body.classList.add('cm-lock');
    var first = form.querySelector('#cm-name');
    if (first) setTimeout(function () { first.focus(); }, 30);
  }
  function close() { dlg.close(); }

  dlg.addEventListener('close', function () {
    document.body.classList.remove('cm-lock');
    if (lastTrigger) lastTrigger.focus();
  });

  Array.prototype.forEach.call(document.querySelectorAll('[data-open-contact]'), function (el) {
    el.addEventListener('click', open);
  });
  Array.prototype.forEach.call(dlg.querySelectorAll('[data-close-contact]'), function (el) {
    el.addEventListener('click', close);
  });

  /* Click on the dimmed backdrop closes it. */
  dlg.addEventListener('click', function (e) {
    if (e.target !== dlg) return;
    var r = dlg.getBoundingClientRect();
    var inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
    if (!inside) close();
  });

  form.addEventListener('input', function (e) {
    if (e.target.getAttribute('aria-invalid') === 'true' && e.target.checkValidity()) {
      e.target.setAttribute('aria-invalid', 'false');
    }
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var bad = null;
    Array.prototype.forEach.call(form.querySelectorAll('[required]'), function (el) {
      var ok = el.checkValidity();
      el.setAttribute('aria-invalid', ok ? 'false' : 'true');
      if (!ok && !bad) bad = el;
    });
    if (bad) {
      note.textContent = 'Please add your name, a valid email and a message.';
      bad.focus();
      return;
    }

    var fd = new FormData(form);
    var key = fd.get('access_key');

    if (!key || key === PLACEHOLDER) {
      var body = [
        'Name: ' + (fd.get('name') || ''),
        'Email: ' + (fd.get('email') || ''),
        'Company: ' + (fd.get('company') || ''),
        'About: ' + (fd.get('topic') || ''),
        '',
        fd.get('message') || ''
      ].join('\n');
      note.textContent = 'Opening your email app with this message.';
      window.location.href = 'mailto:info@nodebriks.com?subject=' +
        encodeURIComponent('Message from the portfolio site') +
        '&body=' + encodeURIComponent(body);
      return;
    }

    var btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    note.textContent = 'Sending.';
    fetch(form.action, { method: 'POST', headers: { 'Accept': 'application/json' }, body: fd })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (r) {
        if (r && r.success) {
          form.reset();
          note.textContent = 'Thanks. I will reply to your email soon.';
        } else {
          note.textContent = 'That did not send. Email info@nodebriks.com instead.';
        }
      })
      .catch(function () { note.textContent = 'That did not send. Email info@nodebriks.com instead.'; })
      .then(function () { btn.disabled = false; });
  });
})();
