#!/usr/bin/env python3
"""Inject the icon sprite, stack grid and AI diagram into the Nodebriks studio page."""

import re, os

ICON_DIR = "/home/claude/package/icons"

# Original glyphs for the six services, drawn to one weight.
GLYPHS = {
    "g-window": '<path d="M3 4h18a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 5v9h16V9H4Zm0-3v1h16V6H4Z"/>',
    "g-phone":  '<path d="M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm0 2v16h10V4H7Zm3.5 14h3v1.2h-3V18Z"/>',
    "g-api":    '<path d="M9.4 4.6 10.8 6 5.8 11l5 5-1.4 1.4L3 11l6.4-6.4Zm5.2 0L21 11l-6.4 6.4L13.2 16l5-5-5-5 1.4-1.4ZM13.1 2.6l1.9.5-4.1 18.3-1.9-.5 4.1-18.3Z"/>',
    "g-spark":  '<path d="M12 2.5 13.7 8l5.5 1.7L13.7 11.4 12 17l-1.7-5.6L4.8 9.7 10.3 8 12 2.5ZM19 14.5l.8 2.4 2.4.8-2.4.8-.8 2.4-.8-2.4-2.4-.8 2.4-.8.8-2.4ZM5.5 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2Z"/>',
    "g-cloud":  '<path d="M7 20a5 5 0 0 1-1-9.9A6.5 6.5 0 0 1 18.4 9 4.6 4.6 0 0 1 18 20H7Zm0-2h11a2.6 2.6 0 0 0 .2-5.2l-1.5-.1-.3-1.5A4.5 4.5 0 0 0 7.9 11l-.2 1.3-1.3.2A3 3 0 0 0 7 18Z"/>',
    "g-wrench": '<path d="M16.2 2a6 6 0 0 0-5.6 8.1l-8 8a1.4 1.4 0 0 0 0 2l1.3 1.3a1.4 1.4 0 0 0 2 0l8-8A6 6 0 0 0 21.6 7l-3 3-2.6-2.6 3-3A6 6 0 0 0 16.2 2ZM4.9 19.6l-.5-.5 7-7 .5.5-7 7Z"/>',
}

STACK = [
    ("Front end", [("react", "React"), ("typescript", "TypeScript"), ("react", "React Native")]),
    ("Back end",  [("nodedotjs", "Node.js"), ("express", "Express"), ("graphql", "GraphQL"), ("python", "Python")]),
    ("Data",      [("postgresql", "PostgreSQL"), ("mongodb", "MongoDB"), ("mysql", "MySQL"), ("redis", "Redis")]),
    ("Platform",  [("docker", "Docker"), ("kubernetes", "Kubernetes"), ("nginx", "Nginx"), ("amazonwebservices", "AWS")]),
    ("AI layer",  [("openai", "Model APIs"), ("langchain", "Orchestration"), ("g-spark", "Vector search")]),
]


def icon_path(slug):
    if slug in GLYPHS:
        return GLYPHS[slug]
    raw = open(os.path.join(ICON_DIR, slug + ".svg"), encoding="utf-8").read()
    return re.search(r'(<path\s+d="[^"]+"\s*/>)', raw).group(1)


# ------------------------------------------------------------------ sprite --
names = list(GLYPHS.keys())
for _, items in STACK:
    for slug, _label in items:
        if slug not in names:
            names.append(slug)

sprite = ['<svg class="sprite" aria-hidden="true" focusable="false" width="0" height="0">']
for n in names:
    sprite.append(f'<symbol id="{n if n.startswith("g-") else n}" viewBox="0 0 24 24">{icon_path(n)}</symbol>')
sprite.append("</svg>")
sprite = "\n".join(sprite)

# -------------------------------------------------------------- stack grid --
cols = []
for title, items in STACK:
    chips = "\n".join(
        f'        <li><svg aria-hidden="true"><use href="#{slug}"></use></svg>{label}</li>'
        for slug, label in items
    )
    cols.append(f'''    <div class="stack-col">
      <h3>{title}</h3>
      <ul>
{chips}
      </ul>
    </div>''')
stack_grid = '<div class="stack-grid">\n' + "\n".join(cols) + "\n  </div>"

# --------------------------------------------------------------- AI figure --
BOXES = [
    (14,  "Your systems",        "Database, documents, tickets, email"),
    (98,  "Retrieval",           "Only the records this one request needs"),
    (182, "Model",               "Drafts an answer or extracts the fields"),
    (266, "Checks",              "Rules, confidence score, human review"),
    (350, "Your application",    "The answer, with its source attached"),
]

parts = []
for y, title, sub in BOXES:
    fill = "#ffffff" if title != "Model" else "#fdece5"
    stroke = "#cdd7db" if title != "Model" else "#ef5a2a"
    parts.append(f'''  <rect x="1" y="{y}" width="330" height="58" fill="{fill}" stroke="{stroke}"/>
  <text x="16" y="{y + 24}" class="d-t">{title}</text>
  <text x="16" y="{y + 43}" class="d-s">{sub}</text>''')
    if y != BOXES[-1][0]:
        parts.append(f'  <path d="M166 {y + 58} v18" stroke="#9fb0b7" stroke-width="1.5"/>'
                     f'<path d="M161 {y + 71} l5 5 5-5" fill="none" stroke="#9fb0b7" stroke-width="1.5"/>')

diagram = f'''<svg class="flow" viewBox="0 0 470 412" role="img" aria-labelledby="flow-t">
  <title id="flow-t">How an AI feature is wired: your systems, retrieval, the model, checks, then your application. Every step is logged.</title>
{chr(10).join(parts)}
  <path d="M331 43 h64 a8 8 0 0 1 8 8 v270 a8 8 0 0 1 -8 8 h-64" fill="none" stroke="#cdd7db" stroke-dasharray="3 3"/>
  <text x="404" y="186" class="d-side" transform="rotate(90 404 186)">Logged: input, output, cost</text>
</svg>'''


# ---------------------------------------------------------- hero schematic --
LAYERS = [
    ("Interface",      "Web and mobile, what your customers touch"),
    ("API",            "Business rules, auth, integrations"),
    ("Data",           "The records the business actually runs on"),
    ("Infrastructure", "Containers, deploys, backups, monitoring"),
]

rows = []
for i, (title, sub) in enumerate(LAYERS):
    y = 18 + i * 72
    rows.append(
        f'  <g class="layer" style="--i:{i}">'
        f'<rect x="12" y="{y}" width="300" height="54" />'
        f'<text x="30" y="{y + 23}" class="h-t">{title}</text>'
        f'<text x="30" y="{y + 41}" class="h-s">{sub}</text>'
        f'</g>'
    )
    rows.append(f'  <path class="tick" d="M312 {y + 27} H 338" />')

hero_stack = f"""<svg class="hero-stack" viewBox="0 0 400 320" role="presentation">
{chr(10).join(rows)}
  <path class="spine" d="M338 45 V 261" />
  <g class="pulse"><circle cx="338" cy="45" r="5"/></g>
</svg>"""

# ------------------------------------------------------------------- write --
src = open("/home/claude/studio/index.src.html", encoding="utf-8").read()
src = src.replace("<!--SPRITE-->", sprite)
src = src.replace("<!--STACK_GRID-->", stack_grid)
src = src.replace("<!--AI_DIAGRAM-->", diagram)
src = src.replace("<!--HERO_STACK-->", hero_stack)
open("/home/claude/studio/index.html", "w", encoding="utf-8").write(src)
print("built:", len(names), "icons")
