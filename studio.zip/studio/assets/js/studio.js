(function () {
  'use strict';

  var yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();

  var form = document.getElementById('enquiry');
  var note = document.getElementById('form-note');
  if (!form || !note) return;

  var KEY_FIELD = form.querySelector('[name="access_key"]');
  var PLACEHOLDER = 'REPLACE-WITH-YOUR-WEB3FORMS-KEY';

  function setNote(text, kind) {
    note.textContent = text;
    note.className = 'form-note' + (kind ? ' is-' + kind : '');
  }

  function mailtoFallback(data) {
    var body = [
      'Name: ' + (data.name || ''),
      'Email: ' + (data.email || ''),
      'Company: ' + (data.company || ''),
      'Needs: ' + (data.need || ''),
      '',
      data.message || ''
    ].join('\n');
    window.location.href =
      'mailto:info@nodebriks.com?subject=' + encodeURIComponent('Project enquiry') +
      '&body=' + encodeURIComponent(body);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    /* Validate before anything else, so the fallback carries real content. */
    var required = form.querySelectorAll('[required]');
    var firstBad = null;
    Array.prototype.forEach.call(required, function (el) {
      var ok = el.checkValidity();
      el.setAttribute('aria-invalid', ok ? 'false' : 'true');
      if (!ok && !firstBad) firstBad = el;
    });
    if (firstBad) {
      setNote('Please fill in your name, email and a short description.', 'err');
      firstBad.focus();
      return;
    }

    var fd = new FormData(form);
    var data = {};
    fd.forEach(function (v, k) { data[k] = v; });

    /* No form key configured yet: hand the message to the mail client
       instead of posting it into a void. */
    if (!KEY_FIELD || KEY_FIELD.value === PLACEHOLDER) {
      setNote('Opening your email app with these details.', 'ok');
      mailtoFallback(data);
      return;
    }

    var btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    setNote('Sending.');

    fetch(form.action, {
      method: 'POST',
      headers: { 'Accept': 'application/json' },
      body: fd
    })
      .then(function (r) { return r.json().catch(function () { return {}; }); })
      .then(function (r) {
        if (r && r.success) {
          form.reset();
          setNote('Thanks. We will reply to your email, usually the same day.', 'ok');
        } else {
          setNote('That did not send. Email info@nodebriks.com instead.', 'err');
        }
      })
      .catch(function () {
        setNote('That did not send. Email info@nodebriks.com instead.', 'err');
      })
      .then(function () { btn.disabled = false; });
  });

  /* Clear the invalid state as soon as someone starts fixing a field. */
  form.addEventListener('input', function (e) {
    if (e.target.getAttribute('aria-invalid') === 'true' && e.target.checkValidity()) {
      e.target.setAttribute('aria-invalid', 'false');
    }
  });
})();
